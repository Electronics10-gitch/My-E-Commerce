"""
6.3.3 UpdateCart — add/update/remove a cart line and recompute the total.
CartItem rows ARE the "hash map: productId -> {quantity, unitPrice}" from
the pseudocode; the DB's (user_id, product_id) primary key gives the same
O(1)-by-key semantics the in-memory version relied on.
"""
from app.models.models import CartItem
from app.repositories.cart_repo import CartRepository
from app.repositories.product_repo import ProductRepository


class CartError(Exception):
    pass


def update_cart(cart_repo: CartRepository, product_repo: ProductRepository,
                 user_id: str, product_id: str, quantity_change: int):
    line = cart_repo.get_line(user_id, product_id)

    if line:
        line.quantity += quantity_change
        if line.quantity <= 0:
            cart_repo.delete_line(user_id, product_id)
        else:
            cart_repo.upsert(line)
    elif quantity_change > 0:
        product = product_repo.get_by_id(product_id)
        if not product:
            raise CartError("Product not found.")
        cart_repo.upsert(CartItem(user_id=user_id, product_id=product_id, quantity=quantity_change))

    return get_cart_with_total(cart_repo, product_repo, user_id)


def get_cart_with_total(cart_repo: CartRepository, product_repo: ProductRepository, user_id: str):
    lines = cart_repo.get_cart(user_id)
    total = 0.0
    enriched = []
    for line in lines:
        product = product_repo.get_by_id(line.product_id)
        if not product:
            continue
        line_total = product.price * line.quantity
        total += line_total
        enriched.append({
            "product_id": product.id,
            "name": product.name,
            "unit_price": product.price,
            "quantity": line.quantity,
            "line_total": line_total,
        })
    return {"items": enriched, "total": total}
