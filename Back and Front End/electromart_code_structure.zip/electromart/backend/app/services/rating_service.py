"""
6.3.6 UpdateRating — O(1) incremental average update, avoids recomputing
over full review history on every new review.
"""
from app.models.models import Review, Product
from app.repositories.product_repo import ProductRepository


def update_rating(db, product_repo: ProductRepository, product_id: str,
                   buyer_id: str, rating_value: int, comment: str = ""):
    product = product_repo.get_by_id(product_id)
    if not product:
        raise ValueError("Product not found.")

    review = Review(product_id=product_id, buyer_id=buyer_id, rating=rating_value, comment=comment)
    db.add(review)

    product.rating_sum += rating_value
    product.rating_count += 1
    product.average_rating = product.rating_sum / product.rating_count

    db.commit()
    db.refresh(product)
    return product.average_rating
