"""
6.3.5 AdvanceOrderStatus — validated state machine + append-only history.
"""
import json
import time
from app.models.models import OrderStatus
from app.repositories.order_repo import OrderRepository

# Valid forward transitions (plus 'cancelled'/'returned' as escape hatches
# from any pre-delivery state — adjust to match final business rules).
VALID_TRANSITIONS = {
    OrderStatus.placed: {OrderStatus.processing, OrderStatus.cancelled},
    OrderStatus.processing: {OrderStatus.shipped, OrderStatus.cancelled},
    OrderStatus.shipped: {OrderStatus.delivered},
    OrderStatus.delivered: {OrderStatus.returned},
    OrderStatus.returned: set(),
    OrderStatus.cancelled: set(),
}


class OrderStatusError(Exception):
    pass


def is_valid_transition(current: OrderStatus, next_status: OrderStatus) -> bool:
    return next_status in VALID_TRANSITIONS.get(current, set())


def advance_order_status(order_repo: OrderRepository, order_id: str, next_status: str,
                          notify_buyer=lambda order, status: None):
    order = order_repo.get_by_id(order_id)
    if not order:
        raise OrderStatusError("Order not found.")

    next_enum = OrderStatus(next_status)
    if not is_valid_transition(order.status, next_enum):
        raise OrderStatusError(f"Invalid status transition: {order.status} -> {next_status}")

    order.status = next_enum
    history = json.loads(order.status_history or "[]")
    history.append({"status": next_status, "timestamp": time.time()})
    order.status_history = json.dumps(history)

    order_repo.save(order)
    notify_buyer(order, next_status)
    return order
