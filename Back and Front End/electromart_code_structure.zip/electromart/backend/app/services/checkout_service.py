"""
6.3.4 PlaceOrder — stock check, payment capture, order creation as one
logical transaction, matching 7.4's "Transactions" requirement.
"""
import json
import time
from app.models.models import Order, OrderItem, OrderStatus
from app.repositories.cart_repo import CartRepository
from app.repositories.product_repo import ProductRepository
from app.repositories.order_repo import OrderRepository


class CheckoutError(Exception):
    pass


def call_payment_gateway(payment_method: str, total: float) -> dict:
    """
    Stand-in for a real payment gateway call. Replace with the actual
    provider SDK/HTTP call — this function's contract (a dict with
    'status' and 'transaction_id') is what the rest of PlaceOrder relies on.
    """
    return {"status": "success", "transaction_id": f"txn_{int(time.time() * 1000)}"}


def place_order(db, cart_repo: CartRepository, product_repo: ProductRepository,
                 order_repo: OrderRepository, buyer_id: str, payment_method: str):
    cart_lines = cart_repo.get_cart(buyer_id)
    if not cart_lines:
        raise CheckoutError("Your cart is empty.")

    # 1. Stock check for every line before touching anything.
    resolved = []
    for line in cart_lines:
        product = product_repo.get_by_id(line.product_id)
        if not product or product.removed:
            raise CheckoutError(f"Product {line.product_id} is no longer available.")
        if product.stock < line.quantity:
            raise CheckoutError(f"Insufficient stock for {product.name}.")
        resolved.append((product, line.quantity))

    total = sum(p.price * qty for p, qty in resolved)

    # 2. Payment capture.
    payment_result = call_payment_gateway(payment_method, total)
    if payment_result["status"] != "success":
        raise CheckoutError("Payment failed.")

    try:
        # 3. Decrement stock + create order, as a single DB transaction.
        for product, qty in resolved:
            product.stock -= qty
            db.add(product)

        order = Order(
            buyer_id=buyer_id,
            total=total,
            status=OrderStatus.placed,
            status_history=json.dumps([{"status": "placed", "timestamp": time.time()}]),
            payment_transaction_id=payment_result["transaction_id"],
        )
        db.add(order)
        db.flush()  # get order.id before creating child rows

        for product, qty in resolved:
            db.add(OrderItem(order_id=order.id, product_id=product.id,
                              quantity=qty, unit_price_at_purchase=product.price))

        db.commit()
        db.refresh(order)
    except Exception:
        db.rollback()
        raise

    # 5. Clear cart only after the order transaction succeeds.
    cart_repo.clear(buyer_id)

    # 6. In a full deployment: enqueue `order.id` onto a FIFO fulfilment
    # queue (e.g. a message broker) for sellers/admin to process in order.

    return order
