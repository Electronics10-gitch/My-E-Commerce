"""
6.3.1 SearchProducts — service layer wraps the repository query with
sorting and pagination, matching the pseudocode's SORT + paginate() steps.
"""
from app.repositories.product_repo import ProductRepository


def search_products(
    repo: ProductRepository,
    keyword: str | None,
    category_id: str | None = None,
    min_price: float | None = None,
    max_price: float | None = None,
    min_rating: float | None = None,
    sort: str = "relevance",
    page: int = 1,
    page_size: int = 20,
):
    results = repo.search(keyword, category_id, min_price, max_price, min_rating)

    if sort == "price_asc":
        results.sort(key=lambda p: p.price)
    elif sort == "price_desc":
        results.sort(key=lambda p: p.price, reverse=True)
    elif sort == "rating_desc":
        results.sort(key=lambda p: p.average_rating, reverse=True)
    # 'relevance' left as returned by the repository (DB order / future
    # full-text rank) — sorting it further here would discard that rank.

    start = (page - 1) * page_size
    return results[start:start + page_size], len(results)
