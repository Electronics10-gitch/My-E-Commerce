"""
6.3.2 ComparePrice — compares a listed product's price against cached
reference-platform prices. The cache itself (populated by a scheduled job,
per the pseudocode's "Note") is out of scope for this skeleton; this module
just defines the shape of that cache and the comparison logic against it.
"""
from dataclasses import dataclass

PLATFORMS = ["Konga", "Jumia", "AliExpress", "Slot", "Jiji"]


@dataclass
class ExternalPrice:
    platform: str
    price: float


def compare_price(product_price: float, cached_external_prices: list[ExternalPrice]):
    """
    cached_external_prices: whatever the background refresh job last stored
    for this product (see 6.5 — 'ComparePrice: scheduled background job +
    fast read from cache at request time'). This function does no fetching.
    """
    comparisons = []
    for ext in cached_external_prices:
        comparisons.append({
            "platform": ext.platform,
            "price": ext.price,
            "delta": round(product_price - ext.price, 2),
        })

    all_prices = comparisons + [{"platform": "ElectroMart", "price": product_price, "delta": 0}]
    cheapest = min(all_prices, key=lambda c: c["price"])
    return {"comparisons": comparisons, "cheapest": cheapest}
