"""
Repository pattern (7.4) for Product. Keeps SQL/ORM specifics out of the
search service (Section 6.3.1) — the service passes filter *criteria* in,
this repo turns them into a query.
"""
from sqlalchemy.orm import Session
from sqlalchemy import and_
from app.models.models import Product


class ProductRepository:
    def __init__(self, db: Session):
        self.db = db

    def get_by_id(self, product_id: str) -> Product | None:
        return self.db.get(Product, product_id)

    def search(
        self,
        keyword: str | None,
        category_id: str | None,
        min_price: float | None,
        max_price: float | None,
        min_rating: float | None,
        include_removed: bool = False,
    ) -> list[Product]:
        q = self.db.query(Product)
        if not include_removed:
            q = q.filter(Product.removed.is_(False))
        conditions = []
        if keyword:
            like = f"%{keyword.lower()}%"
            # A real deployment would back this with a full-text/inverted
            # index (6.3.1 note); a LIKE scan is the direct SQL equivalent
            # of the pseudocode's "product.searchTokens CONTAINS keyword".
            conditions.append(Product.name.ilike(like))
        if category_id:
            conditions.append(Product.category_id == category_id)
        if min_price is not None:
            conditions.append(Product.price >= min_price)
        if max_price is not None:
            conditions.append(Product.price <= max_price)
        if min_rating is not None:
            conditions.append(Product.average_rating >= min_rating)
        if conditions:
            q = q.filter(and_(*conditions))
        return q.all()

    def create(self, product: Product) -> Product:
        self.db.add(product)
        self.db.commit()
        self.db.refresh(product)
        return product

    def save(self, product: Product) -> Product:
        self.db.commit()
        self.db.refresh(product)
        return product

    def list_by_seller(self, seller_id: str) -> list[Product]:
        return self.db.query(Product).filter(Product.seller_id == seller_id).all()

    def list_all(self, include_removed: bool = True) -> list[Product]:
        q = self.db.query(Product)
        if not include_removed:
            q = q.filter(Product.removed.is_(False))
        return q.all()
