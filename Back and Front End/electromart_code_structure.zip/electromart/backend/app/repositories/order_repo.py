from sqlalchemy.orm import Session
from app.models.models import Order, OrderItem


class OrderRepository:
    def __init__(self, db: Session):
        self.db = db

    def get_by_id(self, order_id: str) -> Order | None:
        return self.db.get(Order, order_id)

    def list_by_buyer(self, buyer_id: str) -> list[Order]:
        return (
            self.db.query(Order)
            .filter(Order.buyer_id == buyer_id)
            .order_by(Order.created_at.desc())
            .all()
        )

    def list_by_seller(self, seller_id: str) -> list[Order]:
        # orders containing at least one item sold by this seller
        return (
            self.db.query(Order)
            .join(OrderItem, OrderItem.order_id == Order.id)
            .join(Order.items)
            .filter(OrderItem.product.has(seller_id=seller_id))
            .distinct()
            .all()
        )

    def create(self, order: Order) -> Order:
        self.db.add(order)
        self.db.commit()
        self.db.refresh(order)
        return order

    def save(self, order: Order) -> Order:
        self.db.commit()
        self.db.refresh(order)
        return order

    def all(self) -> list[Order]:
        return self.db.query(Order).all()
