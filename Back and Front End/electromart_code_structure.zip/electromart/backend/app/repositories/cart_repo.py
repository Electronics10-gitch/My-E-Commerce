from sqlalchemy.orm import Session
from app.models.models import CartItem


class CartRepository:
    def __init__(self, db: Session):
        self.db = db

    def get_line(self, user_id: str, product_id: str) -> CartItem | None:
        return self.db.get(CartItem, (user_id, product_id))

    def get_cart(self, user_id: str) -> list[CartItem]:
        return self.db.query(CartItem).filter(CartItem.user_id == user_id).all()

    def upsert(self, line: CartItem) -> CartItem:
        self.db.merge(line)
        self.db.commit()
        return line

    def delete_line(self, user_id: str, product_id: str) -> None:
        line = self.get_line(user_id, product_id)
        if line:
            self.db.delete(line)
            self.db.commit()

    def clear(self, user_id: str) -> None:
        self.db.query(CartItem).filter(CartItem.user_id == user_id).delete()
        self.db.commit()
