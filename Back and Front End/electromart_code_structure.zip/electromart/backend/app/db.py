"""
Database engine & session factory.

Section 7.4 — Data Access Layer: connection pooling is handled by
SQLAlchemy's engine (pool_size / max_overflow below); repositories obtain
a session from `get_db()` per request rather than opening a raw connection.

Swap `DATABASE_URL` for Postgres/MySQL in production; nothing above this
layer (services, API) needs to change.
"""
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

DATABASE_URL = os.environ.get("DATABASE_URL", "sqlite:///./electromart.db")

connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args, pool_pre_ping=True)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    """FastAPI dependency: yields one session per request, closes it after."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db():
    """Create tables. Call once at startup (see main.py)."""
    from app.models import models  # noqa: F401 (ensures models are registered)
    Base.metadata.create_all(bind=engine)
