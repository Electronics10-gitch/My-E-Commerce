import json
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db import get_db
from app.schemas import CheckoutRequest, OrderStatusUpdate, ReviewCreate
from app.repositories.cart_repo import CartRepository
from app.repositories.product_repo import ProductRepository
from app.repositories.order_repo import OrderRepository
from app.services.checkout_service import place_order, CheckoutError
from app.services.order_service import advance_order_status, OrderStatusError
from app.services.rating_service import update_rating
from app.deps import get_current_user, require_role
from app.models.models import User

router = APIRouter(tags=["orders"])


def _serialize_order(order):
    return {
        "id": order.id,
        "buyer_id": order.buyer_id,
        "total": order.total,
        "status": order.status.value,
        "status_history": json.loads(order.status_history or "[]"),
        "payment_transaction_id": order.payment_transaction_id,
        "items": [
            {"product_id": i.product_id, "quantity": i.quantity, "unit_price": i.unit_price_at_purchase}
            for i in order.items
        ],
    }


@router.post("/checkout")
def checkout(payload: CheckoutRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    try:
        order = place_order(db, CartRepository(db), ProductRepository(db), OrderRepository(db),
                             user.id, payload.payment_method)
    except CheckoutError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return _serialize_order(order)


@router.get("/orders")
def list_orders(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    repo = OrderRepository(db)
    orders = repo.list_by_seller(user.id) if user.role == "seller" else repo.list_by_buyer(user.id)
    return [_serialize_order(o) for o in orders]


@router.get("/orders/{order_id}")
def get_order(order_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    order = OrderRepository(db).get_by_id(order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Order not found.")
    if user.role not in ("admin", "seller") and order.buyer_id != user.id:
        raise HTTPException(status_code=403, detail="Not your order.")
    return _serialize_order(order)


@router.patch("/orders/{order_id}/status")
def update_status(order_id: str, payload: OrderStatusUpdate, db: Session = Depends(get_db),
                   user: User = Depends(require_role("seller", "admin"))):
    try:
        order = advance_order_status(OrderRepository(db), order_id, payload.next_status)
    except OrderStatusError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return _serialize_order(order)


@router.post("/orders/{order_id}/feedback")
def submit_feedback(order_id: str, payload: ReviewCreate, db: Session = Depends(get_db),
                     user: User = Depends(get_current_user)):
    order = OrderRepository(db).get_by_id(order_id)
    if not order or order.buyer_id != user.id:
        raise HTTPException(status_code=404, detail="Order not found.")
    if order.status.value != "delivered":
        raise HTTPException(status_code=400, detail="Order has not been delivered yet.")
    # Rates the first item's product as a simple example — a full
    # implementation would let the buyer rate each line item.
    if not order.items:
        raise HTTPException(status_code=400, detail="Order has no items.")
    from app.repositories.product_repo import ProductRepository as _PR
    avg = update_rating(db, _PR(db), order.items[0].product_id, user.id, payload.rating, payload.comment)
    return {"average_rating": avg}
