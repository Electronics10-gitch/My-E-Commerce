from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db import get_db
from app.models.models import ChatThread, ChatMessage
from app.deps import get_current_user
from app.models.models import User

router = APIRouter(tags=["chat"])


@router.get("/chats/{thread_id}/messages")
def get_messages(thread_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    thread = db.get(ChatThread, thread_id)
    if not thread or user.id not in (thread.buyer_id, thread.seller_id):
        raise HTTPException(status_code=404, detail="Thread not found.")
    messages = (
        db.query(ChatMessage)
        .filter(ChatMessage.thread_id == thread_id)
        .order_by(ChatMessage.timestamp.asc())
        .all()
    )
    return [{"sender_id": m.sender_id, "content": m.content, "timestamp": m.timestamp} for m in messages]


@router.post("/chats/{thread_id}/messages")
def send_message(thread_id: str, content: str, db: Session = Depends(get_db),
                  user: User = Depends(get_current_user)):
    thread = db.get(ChatThread, thread_id)
    if not thread or user.id not in (thread.buyer_id, thread.seller_id):
        raise HTTPException(status_code=404, detail="Thread not found.")
    msg = ChatMessage(thread_id=thread_id, sender_id=user.id, content=content)
    db.add(msg)
    db.commit()
    return {"status": "sent"}


@router.get("/notifications")
def get_notifications(user: User = Depends(get_current_user)):
    # Placeholder — a real implementation would read from a Notification
    # table populated by order-status changes, new messages, etc.
    return []
