from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db import get_db
from app.schemas import CartItemIn
from app.repositories.cart_repo import CartRepository
from app.repositories.product_repo import ProductRepository
from app.services.cart_service import update_cart, get_cart_with_total, CartError
from app.deps import get_current_user
from app.models.models import User

router = APIRouter(prefix="/cart", tags=["cart"])


@router.get("")
def get_cart(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return get_cart_with_total(CartRepository(db), ProductRepository(db), user.id)


@router.post("/items")
def add_item(payload: CartItemIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    try:
        return update_cart(CartRepository(db), ProductRepository(db), user.id,
                            payload.product_id, abs(payload.quantity_change) or 1)
    except CartError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.patch("/items/{product_id}")
def change_quantity(product_id: str, payload: CartItemIn, db: Session = Depends(get_db),
                     user: User = Depends(get_current_user)):
    try:
        return update_cart(CartRepository(db), ProductRepository(db), user.id,
                            product_id, payload.quantity_change)
    except CartError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.delete("/items/{product_id}")
def remove_item(product_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    CartRepository(db).delete_line(user.id, product_id)
    return get_cart_with_total(CartRepository(db), ProductRepository(db), user.id)
