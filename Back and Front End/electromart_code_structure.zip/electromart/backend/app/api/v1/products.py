"""
7.3 Products & Catalogue endpoints. Thin — all real logic lives in
app.services.search_service, per the layered architecture in 7.1.
"""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from app.db import get_db
from app.schemas import ProductOut, ProductCreate
from app.repositories.product_repo import ProductRepository
from app.services.search_service import search_products
from app.services.pricing_service import compare_price, PLATFORMS, ExternalPrice
from app.deps import get_current_user, require_role
from app.models.models import Product, User

router = APIRouter(prefix="/products", tags=["products"])


@router.get("")
def list_products(
    keyword: str | None = Query(default=None, alias="q"),
    category_id: str | None = None,
    min_price: float | None = None,
    max_price: float | None = None,
    min_rating: float | None = None,
    sort: str = "relevance",
    page: int = 1,
    page_size: int = 20,
    db: Session = Depends(get_db),
):
    repo = ProductRepository(db)
    results, total = search_products(
        repo, keyword, category_id, min_price, max_price, min_rating, sort, page, page_size
    )
    return {
        "data": [ProductOut.model_validate(p) for p in results],
        "page": page,
        "page_size": page_size,
        "total": total,
    }


@router.get("/{product_id}", response_model=ProductOut)
def get_product(product_id: str, db: Session = Depends(get_db)):
    repo = ProductRepository(db)
    product = repo.get_by_id(product_id)
    if not product or product.removed:
        raise HTTPException(status_code=404, detail="Product not found.")
    return ProductOut.model_validate(product)


@router.get("/{product_id}/price-comparison")
def get_price_comparison(product_id: str, db: Session = Depends(get_db)):
    repo = ProductRepository(db)
    product = repo.get_by_id(product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found.")
    # Stand-in cached prices — replace with a real cache lookup keyed by
    # product.match_key, populated by the scheduled refresh job (6.5).
    cached = [ExternalPrice(platform=p, price=product.price * 1.15) for p in PLATFORMS]
    return compare_price(product.price, cached)


@router.post("", response_model=ProductOut)
def create_product(
    payload: ProductCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_role("seller")),
):
    repo = ProductRepository(db)
    product = repo.create(Product(
        seller_id=user.id,
        category_id=payload.category_id,
        name=payload.name,
        description=payload.description,
        price=payload.price,
        stock=payload.stock,
    ))
    return ProductOut.model_validate(product)


@router.put("/{product_id}", response_model=ProductOut)
def update_product(
    product_id: str,
    payload: ProductCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_role("seller")),
):
    repo = ProductRepository(db)
    product = repo.get_by_id(product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found.")
    if product.seller_id != user.id:
        raise HTTPException(status_code=403, detail="You can only edit your own listings.")
    product.name = payload.name
    product.description = payload.description
    product.price = payload.price
    product.stock = payload.stock
    product.category_id = payload.category_id
    return ProductOut.model_validate(repo.save(product))


@router.delete("/{product_id}")
def delete_product(
    product_id: str,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    repo = ProductRepository(db)
    product = repo.get_by_id(product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found.")
    if user.role not in ("admin",) and product.seller_id != user.id:
        raise HTTPException(status_code=403, detail="Not authorized to remove this listing.")
    product.removed = True
    repo.save(product)
    return {"status": "removed"}
