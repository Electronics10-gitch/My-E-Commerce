from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.db import get_db
from app.models.models import Category

router = APIRouter(prefix="/categories", tags=["categories"])


def _to_tree(categories: list[Category], parent_id: str | None = None):
    return [
        {"id": c.id, "name": c.name, "children": _to_tree(categories, c.id)}
        for c in categories
        if c.parent_category_id == parent_id
    ]


@router.get("")
def get_category_tree(db: Session = Depends(get_db)):
    """Returns the full category hierarchy (6.2 — Tree data structure)."""
    categories = db.query(Category).all()
    return _to_tree(categories, None)
