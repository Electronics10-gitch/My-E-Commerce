from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.db import get_db
from app.repositories.product_repo import ProductRepository
from app.repositories.order_repo import OrderRepository
from app.repositories.user_repo import UserRepository
from app.deps import require_role
from app.models.models import User

router = APIRouter(prefix="/admin", tags=["admin"])


@router.get("/reports/sales")
def sales_report(db: Session = Depends(get_db), _: User = Depends(require_role("admin"))):
    orders = OrderRepository(db).all()
    by_product: dict[str, dict] = {}
    total_revenue = 0.0
    total_units = 0
    for order in orders:
        for item in order.items:
            total_revenue += item.unit_price_at_purchase * item.quantity
            total_units += item.quantity
            entry = by_product.setdefault(item.product_id, {"units": 0, "revenue": 0.0})
            entry["units"] += item.quantity
            entry["revenue"] += item.unit_price_at_purchase * item.quantity

    top_products = sorted(
        ({"product_id": pid, **v} for pid, v in by_product.items()),
        key=lambda p: p["revenue"], reverse=True,
    )[:6]

    return {
        "total_revenue": total_revenue,
        "total_units": total_units,
        "orders_count": len(orders),
        "users_count": len(UserRepository(db).list_all()),
        "listings_count": len(ProductRepository(db).list_all()),
        "top_products": top_products,
    }


@router.get("/moderation/listings")
def moderation_listings(db: Session = Depends(get_db), _: User = Depends(require_role("admin"))):
    return ProductRepository(db).list_all()


@router.patch("/moderation/listings/{product_id}")
def toggle_listing(product_id: str, db: Session = Depends(get_db), _: User = Depends(require_role("admin"))):
    repo = ProductRepository(db)
    product = repo.get_by_id(product_id)
    if not product:
        return {"error": "not found"}
    product.removed = not product.removed
    repo.save(product)
    return {"id": product.id, "removed": product.removed}


@router.get("/moderation/users")
def moderation_users(db: Session = Depends(get_db), _: User = Depends(require_role("admin"))):
    return [u for u in UserRepository(db).list_all() if u.role.value != "admin"]


@router.patch("/moderation/users/{user_id}")
def toggle_user(user_id: str, db: Session = Depends(get_db), _: User = Depends(require_role("admin"))):
    repo = UserRepository(db)
    user = repo.get_by_id(user_id)
    if not user or user.role.value == "admin":
        return {"error": "not found or not allowed"}
    user.disabled = not user.disabled
    repo.save(user)
    return {"id": user.id, "disabled": user.disabled}
