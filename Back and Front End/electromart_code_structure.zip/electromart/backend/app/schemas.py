"""
Pydantic schemas — the JSON shapes crossing the API boundary (7.2, 7.6:
input is validated/sanitised here before it reaches the service layer).
"""
from typing import Optional, List
from pydantic import BaseModel, EmailStr, Field


class Envelope(BaseModel):
    """Consistent response shape (7.2 'Consistent response shape')."""
    status: str = "ok"
    data: object = None
    error: Optional[str] = None


class RegisterRequest(BaseModel):
    name: str
    email: EmailStr
    password: str = Field(min_length=8)
    role: str = "buyer"  # 'buyer' | 'seller'


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    token: str
    user: "UserOut"


class UserOut(BaseModel):
    id: str
    name: str
    email: str
    role: str

    class Config:
        from_attributes = True


class ProductOut(BaseModel):
    id: str
    name: str
    description: str
    price: float
    stock: int
    category_id: str
    seller_id: str
    average_rating: float

    class Config:
        from_attributes = True


class ProductCreate(BaseModel):
    name: str
    description: str
    price: float = Field(gt=0)
    stock: int = Field(ge=0)
    category_id: str


class CartItemIn(BaseModel):
    product_id: str
    quantity_change: int  # positive to add, negative to remove


class CheckoutRequest(BaseModel):
    payment_method: str
    address: str
    phone: str


class OrderStatusUpdate(BaseModel):
    next_status: str


class ReviewCreate(BaseModel):
    rating: int = Field(ge=1, le=5)
    comment: str = ""
