"""
FastAPI dependencies for auth — 7.6: role checks enforced server-side.
"""
from fastapi import Depends, HTTPException, Header
from sqlalchemy.orm import Session
from app.db import get_db
from app.auth_utils import decode_access_token
from app.repositories.user_repo import UserRepository
from app.models.models import User


def get_current_user(
    authorization: str | None = Header(default=None),
    db: Session = Depends(get_db),
) -> User:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing or malformed Authorization header.")
    token = authorization.split(" ", 1)[1]
    payload = decode_access_token(token)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid or expired token.")
    user = UserRepository(db).get_by_id(payload["sub"])
    if not user or user.disabled:
        raise HTTPException(status_code=401, detail="Account not found or disabled.")
    return user


def require_role(*roles: str):
    def _checker(user: User = Depends(get_current_user)) -> User:
        if user.role not in roles:
            raise HTTPException(status_code=403, detail=f"Requires role: {' or '.join(roles)}.")
        return user
    return _checker
