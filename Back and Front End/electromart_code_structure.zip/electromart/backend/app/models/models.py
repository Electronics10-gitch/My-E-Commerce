"""
Section 7.5 — Core Data Model (Entities).

Table names are plural/lowercase; relationships mirror the table in the
backend design doc (User, Product, Category, CartItem, Order, OrderItem,
Review, ChatMessage) plus a self-referencing Category tree (Section VI —
Tree data structure).
"""
import enum
import time
import uuid
from sqlalchemy import (
    Column, String, Float, Integer, Boolean, ForeignKey, DateTime, Text, Enum
)
from sqlalchemy.orm import relationship
from app.db import Base


def _id():
    return str(uuid.uuid4())


class Role(str, enum.Enum):
    buyer = "buyer"
    seller = "seller"
    admin = "admin"


class User(Base):
    __tablename__ = "users"
    id = Column(String, primary_key=True, default=_id)
    name = Column(String, nullable=False)
    email = Column(String, unique=True, nullable=False, index=True)
    password_hash = Column(String, nullable=False)
    role = Column(Enum(Role), default=Role.buyer, nullable=False)
    disabled = Column(Boolean, default=False)

    products = relationship("Product", back_populates="seller")
    orders = relationship("Order", back_populates="buyer")


class Category(Base):
    __tablename__ = "categories"
    id = Column(String, primary_key=True, default=_id)
    name = Column(String, nullable=False)
    parent_category_id = Column(String, ForeignKey("categories.id"), nullable=True)

    children = relationship("Category")
    products = relationship("Product", back_populates="category")


class Product(Base):
    __tablename__ = "products"
    id = Column(String, primary_key=True, default=_id)
    seller_id = Column(String, ForeignKey("users.id"), nullable=False)
    category_id = Column(String, ForeignKey("categories.id"), nullable=False)
    name = Column(String, nullable=False)
    description = Column(Text, default="")
    price = Column(Float, nullable=False)
    stock = Column(Integer, default=0)
    images = Column(Text, default="")  # comma-separated URLs, keep simple here
    rating_sum = Column(Float, default=0.0)
    rating_count = Column(Integer, default=0)
    average_rating = Column(Float, default=0.0)
    removed = Column(Boolean, default=False)  # admin moderation flag

    seller = relationship("User", back_populates="products")
    category = relationship("Category", back_populates="products")


class CartItem(Base):
    __tablename__ = "cart_items"
    user_id = Column(String, ForeignKey("users.id"), primary_key=True)
    product_id = Column(String, ForeignKey("products.id"), primary_key=True)
    quantity = Column(Integer, default=1)


class OrderStatus(str, enum.Enum):
    placed = "placed"
    processing = "processing"
    shipped = "shipped"
    delivered = "delivered"
    returned = "returned"
    cancelled = "cancelled"


class Order(Base):
    __tablename__ = "orders"
    id = Column(String, primary_key=True, default=_id)
    buyer_id = Column(String, ForeignKey("users.id"), nullable=False)
    total = Column(Float, default=0.0)
    status = Column(Enum(OrderStatus), default=OrderStatus.placed)
    status_history = Column(Text, default="[]")  # JSON-encoded list, append-only log (6.3.5)
    payment_transaction_id = Column(String, nullable=True)
    created_at = Column(DateTime, default=lambda: time.time())

    buyer = relationship("User", back_populates="orders")
    items = relationship("OrderItem", back_populates="order")


class OrderItem(Base):
    __tablename__ = "order_items"
    id = Column(String, primary_key=True, default=_id)
    order_id = Column(String, ForeignKey("orders.id"), nullable=False)
    product_id = Column(String, ForeignKey("products.id"), nullable=False)
    quantity = Column(Integer, default=1)
    unit_price_at_purchase = Column(Float, nullable=False)

    order = relationship("Order", back_populates="items")
    product = relationship("Product")


class Review(Base):
    __tablename__ = "reviews"
    id = Column(String, primary_key=True, default=_id)
    product_id = Column(String, ForeignKey("products.id"), nullable=False)
    buyer_id = Column(String, ForeignKey("users.id"), nullable=False)
    rating = Column(Integer, nullable=False)  # 1-5
    comment = Column(Text, default="")
    created_at = Column(DateTime, default=lambda: time.time())


class ChatThread(Base):
    __tablename__ = "chat_threads"
    id = Column(String, primary_key=True, default=_id)
    buyer_id = Column(String, ForeignKey("users.id"), nullable=False)
    seller_id = Column(String, ForeignKey("users.id"), nullable=True)  # null = platform support


class ChatMessage(Base):
    __tablename__ = "chat_messages"
    id = Column(String, primary_key=True, default=_id)
    thread_id = Column(String, ForeignKey("chat_threads.id"), nullable=False)
    sender_id = Column(String, ForeignKey("users.id"), nullable=False)
    content = Column(Text, nullable=False)
    timestamp = Column(DateTime, default=lambda: time.time())
