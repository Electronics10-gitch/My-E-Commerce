"""
7.2 Stateless authentication — each request carries a JWT; the server
keeps no session state. Replace SECRET_KEY with an environment-sourced
secret in production (7.7 — never hard-code credentials/keys).
"""
import os
import time
import bcrypt
from jose import jwt, JWTError

SECRET_KEY = os.environ.get("JWT_SECRET", "dev-secret-change-me")
ALGORITHM = "HS256"
TOKEN_TTL_SECONDS = 60 * 60 * 24 * 7  # 7 days

# Using the `bcrypt` library directly (rather than passlib's CryptContext)
# sidesteps a known passlib/bcrypt version-compatibility issue where newer
# bcrypt releases raise on passlib's internal self-test. bcrypt truncates
# at 72 bytes internally, so long passwords are capped defensively here too.


def hash_password(password: str) -> str:
    pw_bytes = password.encode("utf-8")[:72]
    return bcrypt.hashpw(pw_bytes, bcrypt.gensalt()).decode("utf-8")


def verify_password(password: str, password_hash: str) -> bool:
    try:
        return bcrypt.checkpw(password.encode("utf-8")[:72], password_hash.encode("utf-8"))
    except ValueError:
        return False


def create_access_token(user_id: str, role: str) -> str:
    payload = {"sub": user_id, "role": role, "exp": time.time() + TOKEN_TTL_SECONDS}
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)


def decode_access_token(token: str) -> dict | None:
    try:
        return jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
    except JWTError:
        return None
