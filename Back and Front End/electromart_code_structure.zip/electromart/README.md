# ElectroMart — Code Structure

This is the implementation skeleton that follows the design in:

- `05_Frontend_UIUX_Design.md`  → `frontend_flet/`
- `06_Logic_Design_Algorithms_and_Data_Structures.md` → `backend/app/services/`
- `07_Backend_Design_API_and_Data_Access.md` → `backend/app/` (layered architecture)

It is **not wired end-to-end** — it's a real, importable/runnable scaffold with the
architecture, entities, endpoints and algorithms in place, so a team can fill in
the remaining business logic without re-deciding the structure. It does not run
in this chat; download it and run locally (see each sub-README).

```
electromart/
├── backend/                # Section VII — layered architecture
│   └── app/
│       ├── main.py         # FastAPI app, mounts /api/v1 routers
│       ├── db.py           # SQLAlchemy engine/session (SQLite by default)
│       ├── models/         # Section 7.5 — Core Data Model (entities)
│       ├── schemas.py       # Pydantic request/response shapes
│       ├── repositories/   # Data Access Layer — one repo per resource
│       ├── services/       # Service/Logic Layer — Section VI algorithms
│       └── api/v1/         # API Layer — REST endpoints from Section 7.3
├── frontend_flet/          # Section V — Flet UI (Web/Desktop/Mobile)
│   ├── main.py              # App entry + navigation shell
│   ├── api_client.py         # Thin REST client the screens call
│   ├── screens/              # One file per screen in the IA (5.2)
│   └── components/           # Shared widgets (product card, nav bar)
└── README.md (this file)
```

## Why this split

- **API layer never touches the database directly** — it calls a service.
- **Services never issue raw queries** — they call a repository.
- **Repositories are the only place that knows about SQLAlchemy.**

This mirrors 7.1/7.4 exactly, so the caching layer, a different ORM, or a
different database can be swapped in behind the repositories without touching
services or endpoints.

## Running the backend

```bash
cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload
```

## Running the Flet frontend

```bash
cd frontend_flet
pip install flet httpx
python main.py            # desktop window
python main.py --web      # opens in a browser tab instead (see main.py)
```

Set `API_BASE_URL` in `frontend_flet/api_client.py` to point at the running
backend (defaults to `http://127.0.0.1:8000/api/v1`).
