"""
Thin REST client the Flet screens call. Keeps httpx/URL details in one
place, matching 7.1's "one consistent API" for the frontend.
"""
import httpx

API_BASE_URL = "http://127.0.0.1:8000/api/v1"


class ApiError(Exception):
    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.status = status


class ApiClient:
    def __init__(self, base_url: str = API_BASE_URL):
        self.base_url = base_url
        self.token: str | None = None

    def headers(self) -> dict:
        return {"Authorization": f"Bearer {self.token}"} if self.token else {}

    def handle(self, resp: httpx.Response):
        if resp.status_code >= 400:
            try:
                detail = resp.json().get("detail", "Request failed.")
            except Exception:
                detail = "Request failed."
            raise ApiError(detail, resp.status_code)
        return resp.json()

    def register(self, name: str, email: str, password: str, role: str):
        resp = httpx.post(f"{self.base_url}/auth/register",
                           json={"name": name, "email": email, "password": password, "role": role})
        data = self.handle(resp)
        self.token = data["token"]
        return data["user"]

    def login(self, email: str, password: str):
        resp = httpx.post(f"{self.base_url}/auth/login", json={"email": email, "password": password})
        data = self.handle(resp)
        self.token = data["token"]
        return data["user"]

    def list_products(self, keyword: str = "", category_id: str | None = None):
        params = {"q": keyword} if keyword else {}
        if category_id:
            params["category_id"] = category_id
        resp = httpx.get(f"{self.base_url}/products", params=params)
        return self.handle(resp)

    def get_cart(self):
        resp = httpx.get(f"{self.base_url}/cart", headers=self.headers())
        return self.handle(resp)

    def add_to_cart(self, product_id: str, quantity_change: int = 1):
        resp = httpx.post(f"{self.base_url}/cart/items", headers=self.headers(),
                           json={"product_id": product_id, "quantity_change": quantity_change})
        return self.handle(resp)

    def checkout(self, payment_method: str, address: str, phone: str):
        resp = httpx.post(f"{self.base_url}/checkout", headers=self.headers(),
                           json={"payment_method": payment_method, "address": address, "phone": phone})
        return self.handle(resp)

    def list_orders(self):
        resp = httpx.get(f"{self.base_url}/orders", headers=self.headers())
        return self.handle(resp)


# One shared instance the whole app uses — mirrors keeping a single
# authenticated session, the same as a real mobile/desktop client would.
api = ApiClient()
