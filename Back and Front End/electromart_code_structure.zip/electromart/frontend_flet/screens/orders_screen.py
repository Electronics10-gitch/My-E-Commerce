"""5.3 Order Tracking screen — post-purchase visibility."""
import flet as ft
from api_client import api, ApiError


STEP_ORDER = ["placed", "processing", "shipped", "delivered"]


class OrdersScreen:
    def __init__(self, page: ft.Page, shell, go_to):
        self.page = page
        self.shell = shell
        self.go_to = go_to

    def build(self) -> ft.Control:
        col = ft.Column(scroll=ft.ScrollMode.AUTO, expand=True)
        try:
            orders = api.list_orders()
        except ApiError as err:
            return ft.Text(str(err), color=ft.Colors.RED)

        if not orders:
            col.controls.append(ft.Text("No orders yet.", color=ft.Colors.GREY))

        for order in orders:
            step_index = STEP_ORDER.index(order["status"]) if order["status"] in STEP_ORDER else -1
            timeline = ft.Row([
                ft.Chip(label=ft.Text(step), bgcolor=ft.Colors.GREEN_100 if i <= step_index else None)
                for i, step in enumerate(STEP_ORDER)
            ])
            col.controls.append(
                ft.Container(
                    padding=14, border=ft.border.all(1, ft.Colors.GREY_300), border_radius=6,
                    content=ft.Column([
                        ft.Text(f"Order {order['id'][:8]} — ₦{order['total']:,.0f}", weight=ft.FontWeight.BOLD),
                        ft.Text(f"Status: {order['status']}"),
                        timeline,
                    ]),
                )
            )
        return col
