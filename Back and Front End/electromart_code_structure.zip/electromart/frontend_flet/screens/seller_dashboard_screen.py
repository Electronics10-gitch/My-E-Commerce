"""5.3 Seller Dashboard screen — manage listings and orders."""
import flet as ft
import httpx
from api_client import api, ApiError


class SellerDashboardScreen:
    def __init__(self, page: ft.Page, shell, go_to):
        self.page = page
        self.shell = shell
        self.go_to = go_to

    def build(self) -> ft.Control:
        name = ft.TextField(label="Product name", width=320)
        description = ft.TextField(label="Description", width=320, multiline=True)
        price = ft.TextField(label="Price", width=160)
        stock = ft.TextField(label="Stock", width=160)
        category_id = ft.TextField(label="Category ID", width=320)
        status = ft.Text("")

        def create_listing(e):
            try:
                resp = httpx.post(
                    f"{api.base_url}/products",
                    headers=api.headers(),
                    json={
                        "name": name.value, "description": description.value,
                        "price": float(price.value or 0), "stock": int(stock.value or 0),
                        "category_id": category_id.value,
                    },
                )
                data = api.handle(resp)
                status.value = f"Listing published: {data['name']}"
                status.color = ft.Colors.GREEN
            except (ApiError, ValueError) as err:
                status.value = str(err)
                status.color = ft.Colors.RED
            self.page.update()

        return ft.Column([
            ft.Text("Sell a product", size=20, weight=ft.FontWeight.BOLD),
            name, description,
            ft.Row([price, stock]),
            category_id,
            status,
            ft.ElevatedButton("Publish listing", on_click=create_listing),
        ], scroll=ft.ScrollMode.AUTO, expand=True)
