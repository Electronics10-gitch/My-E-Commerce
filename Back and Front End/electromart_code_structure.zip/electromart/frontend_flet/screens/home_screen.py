"""5.3 Home screen — entry point / discovery."""
import flet as ft


class HomeScreen:
    def __init__(self, page: ft.Page, shell, go_to):
        self.page = page
        self.shell = shell
        self.go_to = go_to

    def build(self) -> ft.Control:
        return ft.Column(
            controls=[
                ft.Container(
                    padding=24,
                    bgcolor=ft.Colors.BLUE_GREY_900,
                    content=ft.Column([
                        ft.Text("Electronics, elevated.", size=26, color=ft.Colors.WHITE, weight=ft.FontWeight.BOLD),
                        ft.Text("Curated phones, laptops, audio and smart-home gear.", color=ft.Colors.WHITE70),
                        ft.ElevatedButton("Browse catalogue", on_click=lambda e: self.go_to("shop")),
                    ]),
                ),
            ]
        )
