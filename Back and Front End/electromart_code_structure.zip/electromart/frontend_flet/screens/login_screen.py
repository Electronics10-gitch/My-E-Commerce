"""5.3 Login / Register screen."""
import flet as ft
from api_client import api, ApiError


class LoginScreen:
    def __init__(self, page: ft.Page, on_login):
        self.page = page
        self.on_login = on_login
        self.mode = "login"  # or "register"

    def build(self) -> ft.Control:
        email = ft.TextField(label="Email", width=320)
        password = ft.TextField(label="Password", password=True, can_reveal_password=True, width=320)
        name = ft.TextField(label="Full name", width=320, visible=self.mode == "register")
        role = ft.Dropdown(
            label="Account type", width=320, visible=self.mode == "register",
            options=[ft.dropdown.Option("buyer", "Buyer"), ft.dropdown.Option("seller", "Seller")],
            value="buyer",
        )
        error_text = ft.Text("", color=ft.Colors.RED)

        def submit(e):
            try:
                if self.mode == "login":
                    user = api.login(email.value, password.value)
                else:
                    user = api.register(name.value, email.value, password.value, role.value)
                self.on_login(user)
            except ApiError as err:
                error_text.value = str(err)
                self.page.update()

        def switch_mode(e):
            self.mode = "register" if self.mode == "login" else "login"
            name.visible = self.mode == "register"
            role.visible = self.mode == "register"
            submit_btn.text = "Create account" if self.mode == "register" else "Sign in"
            switch_link.text = "Have an account? Sign in" if self.mode == "register" else "New here? Create an account"
            self.page.update()

        submit_btn = ft.ElevatedButton("Sign in", on_click=submit, width=320)
        switch_link = ft.TextButton("New here? Create an account", on_click=switch_mode)

        return ft.Container(
            alignment=ft.alignment.center,
            expand=True,
            content=ft.Column(
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                controls=[
                    ft.Text("ElectroMart", size=28, weight=ft.FontWeight.BOLD),
                    ft.Text("Électronique — curated tech, delivered.", size=12, color=ft.Colors.GREY),
                    ft.Container(height=20),
                    error_text,
                    name, email, password, role,
                    submit_btn, switch_link,
                ],
            ),
        )
