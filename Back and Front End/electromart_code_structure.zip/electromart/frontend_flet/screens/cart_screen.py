"""5.3 Cart screen — review before purchase."""
import flet as ft
from api_client import api, ApiError


class CartScreen:
    def __init__(self, page: ft.Page, shell, go_to):
        self.page = page
        self.shell = shell
        self.go_to = go_to

    def build(self) -> ft.Control:
        lines_col = ft.Column()
        total_text = ft.Text("", size=16, weight=ft.FontWeight.BOLD)
        address = ft.TextField(label="Delivery address", width=320)
        phone = ft.TextField(label="Phone", width=320)
        payment = ft.Dropdown(
            label="Payment method", width=320, value="card",
            options=[ft.dropdown.Option("card", "Card"), ft.dropdown.Option("transfer", "Bank transfer"),
                     ft.dropdown.Option("cod", "Pay on delivery")],
        )
        status = ft.Text("", color=ft.Colors.RED)

        def refresh(e=None):
            lines_col.controls.clear()
            try:
                cart = api.get_cart()
                for item in cart["items"]:
                    lines_col.controls.append(
                        ft.Row([
                            ft.Text(item["name"], expand=True),
                            ft.Text(f"x{item['quantity']}"),
                            ft.Text(f"₦{item['line_total']:,.0f}"),
                        ])
                    )
                total_text.value = f"Total: ₦{cart['total']:,.0f}"
            except ApiError as err:
                status.value = str(err)
            self.page.update()

        def checkout(e):
            try:
                order = api.checkout(payment.value, address.value, phone.value)
                status.value = f"Order placed — id {order['id']}"
                status.color = ft.Colors.GREEN
                refresh()
            except ApiError as err:
                status.value = str(err)
                status.color = ft.Colors.RED
            self.page.update()

        refresh()

        return ft.Column([
            ft.Text("Your cart", size=20, weight=ft.FontWeight.BOLD),
            lines_col,
            total_text,
            ft.Divider(),
            ft.Text("Checkout", size=16, weight=ft.FontWeight.BOLD),
            address, phone, payment,
            status,
            ft.ElevatedButton("Place order", on_click=checkout),
        ], scroll=ft.ScrollMode.AUTO, expand=True)
