"""5.3 Product Listing (Search Results) screen."""
import flet as ft
from api_client import api, ApiError
from components.product_card import product_card


class ProductListingScreen:
    def __init__(self, page: ft.Page, shell, go_to):
        self.page = page
        self.shell = shell
        self.go_to = go_to

    def build(self) -> ft.Control:
        grid = ft.ResponsiveRow()  # 5.1 — collapses to single column on mobile via col={} below
        status = ft.Text("Loading…", size=12, color=ft.Colors.GREY)

        def add_to_cart(product_id: str):
            try:
                api.add_to_cart(product_id)
                status.value = "Added to cart."
            except ApiError as err:
                status.value = str(err)
            self.page.update()

        def load(keyword: str = ""):
            grid.controls.clear()
            try:
                result = api.list_products(keyword=keyword)
                for p in result["data"]:
                    grid.controls.append(
                        ft.Container(col={"xs": 12, "sm": 6, "md": 4}, content=product_card(p, add_to_cart))
                    )
                status.value = f"{result['total']} item(s) found"
            except ApiError as err:
                status.value = str(err)
            self.page.update()

        search_box = ft.TextField(
            label="Search products…", width=320,
            on_submit=lambda e: load(search_box.value),
        )

        load()  # initial load

        return ft.Column([
            ft.Row([search_box, ft.ElevatedButton("Search", on_click=lambda e: load(search_box.value))]),
            status,
            grid,
        ], scroll=ft.ScrollMode.AUTO, expand=True)
