"""5.3 Admin Dashboard screen — platform oversight."""
import flet as ft
import httpx
from api_client import api, ApiError


class AdminDashboardScreen:
    def __init__(self, page: ft.Page, shell, go_to):
        self.page = page
        self.shell = shell
        self.go_to = go_to

    def build(self) -> ft.Control:
        stats_row = ft.Row(wrap=True)
        try:
            resp = httpx.get(f"{api.base_url}/admin/reports/sales", headers=api.headers())
            report = api.handle(resp)
            stats = [
                ("Revenue", f"₦{report['total_revenue']:,.0f}"),
                ("Units sold", report["total_units"]),
                ("Orders", report["orders_count"]),
                ("Users", report["users_count"]),
                ("Listings", report["listings_count"]),
            ]
            for label, value in stats:
                stats_row.controls.append(
                    ft.Container(
                        padding=14, border=ft.border.all(1, ft.Colors.GREY_300), border_radius=6, width=150,
                        content=ft.Column([ft.Text(label, size=11, color=ft.Colors.GREY), ft.Text(str(value), size=18, weight=ft.FontWeight.BOLD)]),
                    )
                )
        except ApiError as err:
            return ft.Text(str(err), color=ft.Colors.RED)

        return ft.Column([
            ft.Text("Admin — Sales report", size=20, weight=ft.FontWeight.BOLD),
            stats_row,
            ft.Divider(),
            ft.Text("Listing & user moderation is available via the same "
                    "/admin/moderation/* endpoints used here — wire up a "
                    "DataTable against api_client for the full moderation UI.",
                    size=12, color=ft.Colors.GREY),
        ], scroll=ft.ScrollMode.AUTO, expand=True)
