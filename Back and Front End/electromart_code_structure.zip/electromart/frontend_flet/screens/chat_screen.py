"""5.3 Chat Widget screen — buyer-seller/support communication."""
import flet as ft


class ChatScreen:
    def __init__(self, page: ft.Page, shell, go_to):
        self.page = page
        self.shell = shell
        self.go_to = go_to
        self.messages: list[tuple[str, str]] = [
            ("support", "Hi! How can we help with your order today?"),
        ]

    def build(self) -> ft.Control:
        thread = ft.Column(scroll=ft.ScrollMode.AUTO, expand=True)
        input_box = ft.TextField(label="Type a message…", expand=True)

        def render_thread():
            thread.controls = [
                ft.Container(
                    alignment=ft.alignment.center_left if sender == "support" else ft.alignment.center_right,
                    content=ft.Container(
                        padding=10, border_radius=8,
                        bgcolor=ft.Colors.GREY_200 if sender == "support" else ft.Colors.BLUE_100,
                        content=ft.Text(text),
                    ),
                )
                for sender, text in self.messages
            ]

        def send(e):
            if not input_box.value:
                return
            self.messages.append(("buyer", input_box.value))
            input_box.value = ""
            render_thread()
            self.page.update()
            # A real implementation posts to POST /chats/{thread_id}/messages
            # (see backend/app/api/v1/chat.py) instead of this canned reply.
            self.messages.append(("support", "Thanks — our team will follow up on this thread shortly."))
            render_thread()
            self.page.update()

        render_thread()

        return ft.Column([
            ft.Text("Support Chat", size=20, weight=ft.FontWeight.BOLD),
            thread,
            ft.Row([input_box, ft.IconButton(ft.Icons.SEND, on_click=send)]),
        ], expand=True)
