"""
5.2 Information Architecture — app shell + navigation.
Run: python main.py  (desktop window)  |  python main.py --web (browser tab)
"""
import sys
import flet as ft

from screens.login_screen import LoginScreen
from screens.home_screen import HomeScreen
from screens.product_listing_screen import ProductListingScreen
from screens.cart_screen import CartScreen
from screens.orders_screen import OrdersScreen
from screens.seller_dashboard_screen import SellerDashboardScreen
from screens.admin_dashboard_screen import AdminDashboardScreen
from screens.chat_screen import ChatScreen


class AppShell:
    """Holds the logged-in user + drives which screen is on-screen — the
    one shared piece of state every screen file below reads from."""
    def __init__(self):
        self.user: dict | None = None


def main(page: ft.Page):
    page.title = "ElectroMart"
    page.theme_mode = ft.ThemeMode.LIGHT
    # 5.5 Cross-Platform Adaptation: Flet compiles this same tree to
    # Web/Desktop/Mobile; only breakpoint-driven layout (grid columns,
    # nav placement) needs to branch on page.width, not the whole screen.
    page.padding = 0

    shell = AppShell()
    content = ft.Container(expand=True)

    def go_to(view: str):
        screens = {
            "home": HomeScreen,
            "shop": ProductListingScreen,
            "cart": CartScreen,
            "orders": OrdersScreen,
            "sell": SellerDashboardScreen,
            "admin": AdminDashboardScreen,
            "chat": ChatScreen,
        }
        screen_cls = screens.get(view, HomeScreen)
        content.content = screen_cls(page=page, shell=shell, go_to=go_to).build()
        page.update()

    def on_login(user: dict):
        shell.user = user
        page.appbar = build_appbar(page, shell, go_to)
        go_to("home")

    if shell.user is None:
        content.content = LoginScreen(page=page, on_login=on_login).build()

    page.add(content)


def build_appbar(page: ft.Page, shell: AppShell, go_to):
    """Top nav — mirrors the tab bar in 05_Frontend_UIUX_Design.md (5.2/5.3)."""
    tabs = [("Electronics", "shop"), ("My Orders", "orders"), ("Support", "chat")]
    if shell.user and shell.user.get("role") == "seller":
        tabs.append(("Sell", "sell"))
    if shell.user and shell.user.get("role") == "admin":
        tabs.append(("Admin", "admin"))

    return ft.AppBar(
        title=ft.Text("ElectroMart"),
        actions=[
            *[ft.TextButton(label, on_click=lambda e, v=view: go_to(v)) for label, view in tabs],
            ft.IconButton(ft.Icons.SHOPPING_CART, on_click=lambda e: go_to("cart")),
        ],
    )


if __name__ == "__main__":
    if "--web" in sys.argv:
        ft.app(target=main, view=ft.AppView.WEB_BROWSER)
    else:
        ft.app(target=main)
