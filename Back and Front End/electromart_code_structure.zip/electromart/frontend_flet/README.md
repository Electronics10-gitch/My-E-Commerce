# ElectroMart — Flet Frontend

Screens map directly onto the IA in `05_Frontend_UIUX_Design.md` §5.2:

| File | Screen |
|---|---|
| `screens/login_screen.py` | Login / Register |
| `screens/home_screen.py` | Home |
| `screens/product_listing_screen.py` | Product Listing (search/filter/grid) |
| `screens/cart_screen.py` | Cart + Checkout |
| `screens/orders_screen.py` | Order Tracking |
| `screens/seller_dashboard_screen.py` | Seller Dashboard |
| `screens/admin_dashboard_screen.py` | Admin Dashboard |
| `screens/chat_screen.py` | Chat / Support |

`main.py` wires these into one navigable shell via a top `AppBar`
(5.3's nav bar) and hands each screen the shared `api_client.api` session.

## What's stubbed vs. wired

Wired against the real backend: login, register, search, add-to-cart,
checkout, order list, seller listing creation, admin sales report.

Left as stubs to fill in (each has a comment marking it):
- Product Detail screen (image gallery, price-comparison panel, reviews) —
  not yet a separate file; extend `product_listing_screen.py`'s card
  tap-through into one.
- Admin listing/user moderation tables (the report numbers are wired; the
  moderation `DataTable`s are not).
- Chat screen posts to a local list instead of `POST /chats/{id}/messages`.
- Category tree navigation (categories endpoint exists; no UI consumes it yet).

## Run

```bash
pip install flet httpx
python main.py           # desktop window
python main.py --web     # opens in a browser tab
```

Make sure the backend is running first (`uvicorn app.main:app`) and that
`api_client.API_BASE_URL` points at it.
