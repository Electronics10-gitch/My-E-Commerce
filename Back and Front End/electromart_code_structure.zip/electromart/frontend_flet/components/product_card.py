"""Shared product card widget (5.1 — 'built once, adapt layout to screen size')."""
import flet as ft


def product_card(product: dict, on_add_to_cart) -> ft.Control:
    return ft.Container(
        width=220,
        padding=14,
        border=ft.border.all(1, ft.Colors.GREY_300),
        border_radius=6,
        content=ft.Column([
            ft.Text(product["name"], weight=ft.FontWeight.BOLD, size=14),
            ft.Text(f"₦{product['price']:,.0f}", size=13, color=ft.Colors.GREY_700),
            ft.Text(f"Stock: {product['stock']}", size=11, color=ft.Colors.GREY_500),
            ft.ElevatedButton(
                "Add to cart",
                disabled=product["stock"] == 0,
                on_click=lambda e: on_add_to_cart(product["id"]),
            ),
        ]),
    )
